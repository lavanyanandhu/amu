package com.niit.shoppingcart.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.model.Supplier;

public class SupplierTest 
{
	 @SuppressWarnings("resource")
	public static void main(String[] args)
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(); 
		context.scan("com.niit.shoppingcart");
		context.refresh();
		
		
		SupplierDAO supplierDAO = (SupplierDAO)context.getBean("supplierDAO");
		Supplier supplier = (Supplier)context.getBean("supplier");
		supplier.setsid("SUP_001");
		supplier.setsname("BIKE");
		supplier.setsphonenumber("0802345767");
		supplier.setsaddress("london");
		
		
		supplierDAO.addSupplier(supplier);
	}

}
