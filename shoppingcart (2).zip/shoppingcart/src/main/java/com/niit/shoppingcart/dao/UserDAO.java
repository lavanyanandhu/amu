package com.niit.shoppingcart.dao;

import com.niit.shoppingcart.model.User;

public interface UserDAO 
{
	public void addUser(User user);
}
